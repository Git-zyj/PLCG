static const char *srcdir = ".";
