#!/bin/sh
autoreconf -i
